@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $base='%~dp0'; $icon=Join-Path $base 'cee-badge.ico'; if (-not (Test-Path $icon)) { $icon=Join-Path $env:USERPROFILE 'Downloads\cee-badge.ico'; Invoke-WebRequest -UseBasicParsing -Uri 'https://66502af6ae4290.lhr.life/downloads/windows/cee-badge.ico' -OutFile $icon }; if (-not (Test-Path $icon)) { throw 'Unable to locate or download cee-badge.ico.' }; $desktop=[Environment]::GetFolderPath('Desktop'); $shortcut=Join-Path $desktop 'CEE Admin Console.lnk'; $wsh=New-Object -ComObject WScript.Shell; $s=$wsh.CreateShortcut($shortcut); $s.TargetPath=$env:SystemRoot+'\System32\cmd.exe'; $s.Arguments='/c start \"\" \"https://bo.golibe.com/\"'; $s.WorkingDirectory=$desktop; $s.Description='CEE Admin Console'; $s.IconLocation=$icon+',0'; $s.Save(); Start-Process explorer.exe ('/select,'+$shortcut)"
if errorlevel 1 (
  echo Installation failed.
  echo Please check internet connection and try again.
  pause
  exit /b 1
)
echo Done. CEE icon was created on Desktop.
echo Drag it to taskbar to pin.
pause
