@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $base='%~dp0'; $icon=Join-Path $base 'cee-badge.ico'; if (-not (Test-Path $icon)) { throw 'Missing cee-badge.ico next to installer.' }; $desktop=[Environment]::GetFolderPath('Desktop'); $shortcut=Join-Path $desktop 'CEE Admin Console.lnk'; $wsh=New-Object -ComObject WScript.Shell; $s=$wsh.CreateShortcut($shortcut); $s.TargetPath=$env:SystemRoot+'\System32\cmd.exe'; $s.Arguments='/c start \"\" \"https://bo.golibe.com/\"'; $s.WorkingDirectory=$desktop; $s.Description='CEE Admin Console'; $s.IconLocation=$icon+',0'; $s.Save(); Start-Process explorer.exe ('/select,'+$shortcut)"
if errorlevel 1 (
  echo Installation failed.
  echo Make sure this file is extracted from ZIP together with cee-badge.ico.
  echo Then run this installer again.
  pause
  exit /b 1
)
echo Done. CEE icon was created on Desktop.
echo Drag it to taskbar to pin.
pause
